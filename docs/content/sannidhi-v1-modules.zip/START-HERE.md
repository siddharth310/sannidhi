# Sannidhi v1 — start here

Unzip at the repo root (it adds and replaces files; it deletes nothing). Then delete the old
`docs/cursor/P2c*` and `docs/cursor/P2e*` prompts if they are still there.

1. Read `docs/v1/ROADMAP.md` — module order, definition of done, what each module needs from you.
2. Start the critical path today: purohit review, native read, recordings, illustrations, music brief.
3. Make the audio in your browser: open `tools/sannidhi-audio.ipynb` in Google Colab.
4. Run the modules in order in Cursor: M1 → M2 → M3 → M4 → M5 → (M6) → M7 → M8.
   Each prompt is in `docs/cursor/`, each test workbook in `tests/`.
5. Release documents (privacy policy, store listing, data safety, checklist) are in `docs/v1/release/`.
