---
id: ganesha.story.moon
deity: ganesha
title: { te: గణపతి, చంద్రుడు, hi: गणेश जी और चंदा मामा, en: Ganesha and the Moon }
ages: 4-12
minutes: 3
feeling: [kind, safe]
source: Popular retelling (Purāṇic). In the Telugu vratakalpam katha it is Parvati who speaks the curse; this children's telling follows the widely told version where Ganesha does, and explains the moon's phases.
observances: [obs.vinayaka-chavithi]
cover: img.story.ganesha.moon.cover
status: draft
reviewed_by:
music: mus.ganesha.moon
narration: yes          # files in content/audio/stories/ganesha.story.moon/ (see narration/NARRATION-GUIDE.md)
---

## beat 1
image: img.story.ganesha.moon.b1
touch: { target: modaka, effect: bounce, sound: sfx.bounce }
#### te
గణపతి పుట్టినరోజు! అందరూ ఉండ్రాళ్ళు, మోదకాలు తెచ్చారు. ఆయన బొజ్జ నిండా తిన్నాడు.
#### hi
गणेश जी का जन्मदिन! सबने मोदक लाए। उन्होंने पेट भरकर खाए।
#### en
It was Ganesha's birthday! Everyone brought modakas, and he ate until his tummy was round and full.

## beat 2
image: img.story.ganesha.moon.b2
touch: { target: mouse, effect: wiggle, sound: sfx.wiggle }
#### te
రాత్రి ఎలుక మీద ఇంటికి బయలుదేరాడు. చిట్టి ఎలుక కష్టపడి మోసింది.
#### hi
रात को वे चूहे पर बैठकर घर चले। नन्हा चूहा मेहनत से उन्हें ले चला।
#### en
At night he rode home on his mouse. The little mouse puffed and pulled.

## beat 3
image: img.story.ganesha.moon.b3
touch: { target: modakas, effect: appear, sound: sfx.appear }
music: low              # music dips to the drone; never darker
#### te
దారిలో పాము! ఎలుక గెంతింది. గణపతి దొర్లిపడ్డాడు, మోదకాలు అటూ ఇటూ దొర్లాయి.
#### hi
रास्ते में साँप! चूहा उछल पड़ा। गणेश जी लुढ़क गए और मोदक इधर-उधर लुढ़क गए।
#### en
A snake on the path! The mouse jumped. Ganesha tumbled, and the modakas rolled everywhere.

## beat 4
image: img.story.ganesha.moon.b4
touch: { target: moon, effect: glow, sound: sfx.glow }
#### te
ఆకాశంలో చంద్రుడు పకపకా నవ్వాడు. "ఎంత బొజ్జ!" అన్నాడు. గణపతి లేచి, మోదకాలు ఏరుకుని, ప్రశాంతంగా అడిగాడు: "ఎవరైనా పడిపోతే నవ్వడం మంచిదేనా?"
#### hi
आसमान में चंदा मामा ज़ोर से हँस पड़े। "कितना बड़ा पेट!" गणेश जी उठे, मोदक बटोरे और शांति से पूछा, "क्या किसी के गिरने पर हँसना अच्छा है?"
#### en
Up in the sky, the moon laughed and laughed. "What a big tummy!" Ganesha stood up, gathered his modakas and asked calmly, "Is it kind to laugh when someone falls?"

## beat 5
image: img.story.ganesha.moon.b5
touch: { target: moon, effect: hide, sound: sfx.hide }
music: low              # music dips to the drone; never darker
#### te
"నువ్వు దాక్కో" అన్నాడు గణపతి. చంద్రుడు మేఘాల వెనక్కి వెళ్ళిపోయాడు. ఆకాశం చీకటైపోయింది.
#### hi
"छिप जाओ," गणेश जी ने कहा। चंदा मामा बादलों के पीछे चले गए। आसमान अँधेरा हो गया।
#### en
"Go and hide," said Ganesha. The moon slipped behind the clouds, and the sky went dark.

## beat 6
image: img.story.ganesha.moon.b6
touch: { target: moon, effect: appear, sound: sfx.appear }
#### te
"క్షమించు!" అన్నాడు చంద్రుడు. గణపతి క్షమించాడు: "నువ్వు నెలంతా కొంచెం కొంచెం పెరిగి, తగ్గుతావు." "నా పుట్టినరోజు రాత్రి మాత్రం నిన్ను ఎవరూ చూడరు — ఆ రోజు ఏం జరిగిందో గుర్తుగా." అందుకే చవితి నాడు చంద్రుణ్ణి చూడరు.
#### hi
"माफ़ करो!" चंदा मामा बोले। गणेश जी ने माफ़ कर दिया: "तुम हर महीने थोड़ा-थोड़ा बढ़ोगे और घटोगे।" "बस मेरे जन्मदिन की रात तुम्हें कोई नहीं देखेगा — उस दिन की याद में।" इसीलिए चतुर्थी को चाँद नहीं देखते।
#### en
"I'm sorry!" said the moon. Ganesha forgave him: "Each month you'll grow a little, then shrink a little." "Only on my birthday night, no one will look at you — to remember that day." That is why people don't look at the moon on Chavithi.

## beat 7
image: img.story.ganesha.moon.b7
#### te
ఎవరైనా పడిపోతే నవ్వకు, చేయి అందించు. తప్పు చేస్తే "సారీ" చెప్పు.
#### hi
कोई गिरे तो हँसो मत, हाथ बढ़ाओ। और गलती हो तो "सॉरी" कहो।
#### en
When someone falls, don't laugh — help them up. And when you're wrong, say sorry.
