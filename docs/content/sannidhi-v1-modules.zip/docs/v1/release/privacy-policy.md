# Privacy policy — Sannidhi (draft, 24 Oct 2026)

*Draft for review. Not legal advice; have it read by someone who handles app policies before publishing.
Replace the bracketed items.*

**Who we are.** Sannidhi is a devotional app made by [your name], [city], India. Contact: [contact email].

**The short version.** Almost everything you do in Sannidhi stays on your phone. We have no ads, no analytics
and no tracking. If you join or start a chanting group, a small amount of information is stored on our server so
the group can work.

## What stays on your phone only

- Your name, language, state and city, rāśi, nakṣatra and gotra.
- Your japams, counts, reasons and completed sankalpams.
- Puja checklists and settings.
- If you use "Find my nakṣatra", your birth date, time and place are used once on your phone to work out the
  result and are then discarded. Only the result is kept, if you choose to save it.

We cannot see any of this. Deleting the app, or Profile → Delete my data, removes it.

## What is stored if you use groups

To start or join a group you sign in with Google (or Apple on iPhone). We then store, on Google Firebase servers:
- an account identifier from Google or Apple (we do not store your password, phone number or contacts);
- the display name you choose for the group;
- the group's name, purpose, text, goal, days and city (city only, never your address);
- your counts in the group, and your reason only if you choose to show it to the group;
- reports you send about a group (without your identity attached to the report).

Members of a group see your display name, your counts and, if you chose, your reason. Open groups show their
name, purpose, organiser's display name, city and totals to anyone using the app.

## What we never do

No advertising. No selling or sharing of data. No analytics or tracking tools. No access to your contacts,
photos, microphone, camera or location. No OTPs or phone numbers.

## Deleting your data

Profile → Delete my data removes everything on your phone and, if you used groups, your account and
memberships on our server. Counts you already added to a group total remain as numbers without your name.
You can also write to [contact email].

## Children

Stories in Sannidhi are made for families to enjoy with children. Groups are for adults; children should not
sign in. [Adjust to match the target-audience decision in the release checklist.]

## Changes

If this policy changes, the new version will be in the app and at [policy URL], with the date at the top.
